type TextOutputs = Partial<Record<'text/plain' | 'image/png' | 'text/html', string>>;
type ErrorOutput = {
    'application/vnd.code.notebook.error': Error;
};
type ExecuteResult = TextOutputs & Partial<ErrorOutput>;
export interface ILogger {
    info(message: string, ...args: any[]): void;
    error(message: string, ...args: any[]): void;
}
export declare class Kernel {
    private readonly outputs;
    private completed?;
    private readonly kernel;
    /**
     *
     * @param pyodidePath Path to the pyodide assets directory.
     * @param workerPath Path to th comlink.worker.js file.
     */
    constructor({ pyodidePath, workerPath, location, packages, logger }: {
        pyodidePath: string;
        workerPath: string;
        location: string;
        packages: string[];
        logger: ILogger;
    });
    execute(code: string): Promise<ExecuteResult>;
}
export {};
